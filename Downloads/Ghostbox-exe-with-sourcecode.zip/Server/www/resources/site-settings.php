<!--- Edit setting below, according to your own needs --->

<?php 
error_reporting(0);
ini_set('display_errors', 0); // Don't echo php errors

// Set website (Ghostbox) title
$sitetitle = 'IamGhost';

// Set site or profile description
$sitedescription = 'The first ever Ghostbox on the deep webz... Beyond epic!';

// Set date and time
date_default_timezone_set('Africa/Lagos');

// Open or password protected (optional)
require('resources/login.php'); //no login screen, set to login.php to force password protection
?>
<!--- End of settings --->