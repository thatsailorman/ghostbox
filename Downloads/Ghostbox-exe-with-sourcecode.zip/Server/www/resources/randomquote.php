 <?php
 ## Random quote. Configure this acc. to your needs ##
    $Ad[0] = '"No system of mass surveillance has existed in any society that we know of to this point that has not been abused."</b> - Edward Snowden';
    $Ad[1] = '"Even if you are not doing anything wrong, you are being watched and recorded."</b> - Edward Snowden';
    $Ad[2] = '"Democratic societies need a strong media, and WikiLeaks is part of that media."</b> - Julian Assange';
    $Weight[0]=2;
    $Weight[1]=3;
    $Weight[2]=1;
    $sum =0;
    for($i=0;$i<count($Weight);$i++)
    	$sum+=$Weight[$i];
    $ShowAd = rand(0, $sum - 1);
    for($i=0;$i<count($Weight);$i++)
    {
    	if($ShowAd<=$Weight[$i])
    	{
    		$ShowAd=$i;
    		break;
    	}
    	else
    		$ShowAd-=$Weight[$i];
    }
    echo $Ad[$ShowAd];
	## End of random quote ##
	?>