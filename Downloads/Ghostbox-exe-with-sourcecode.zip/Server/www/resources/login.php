<?php
session_start();
error_reporting(0);
ini_set('display_errors', 0);							 
							
if (!isset($_SESSION['loggedIn'])) {
    $_SESSION['loggedIn'] = false;
}



if (isset($_POST['password'])) {
    if (sha1($_POST['password']) == $password) {
		$_SESSION['loggedIn'] = true;
    } else {
        die ('Incorrect password.');
    }
} 

if (!$_SESSION['loggedIn']): ?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Ghostbox</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

	<!--     Fonts and icons     -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

	<!-- CSS Files -->
    <link href="../login-assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../login-assets/css/material-kit.css" rel="stylesheet"/>

</head>

<body class="signup-page">
	<nav class="navbar navbar-transparent navbar-absolute">
    	<div class="container">
        	<!-- Brand and toggle get grouped for better mobile display -->
        	

        	<div class="collapse navbar-collapse" id="navigation-example">
        		<ul class="nav navbar-nav navbar-right">
					<li>
    					<b>Ghostbox [BETA]</b> Self-hosted, anonymous, file sharing alternative for the dark web.
    				</li>
        		</ul>
        	</div>
    	</div>
    </nav>

    <div class="wrapper">
		<div class="header header-filter" style="background-image: url('../login-assets/img/city.jpg'); background-size: cover; background-position: top center;">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
						<div class="card card-signup">
							<form class="form" method="post">
								<div class="header header-primary text-center">
									<h4><i class='material-icons'>lock_outline</i> This is not an open <b>[G]hostbox</b>.</h4>
									
								</div>
								<p class="text-divider">Please enter the secret Ghostbox password<br>to gain access to the shared files and folders.<br></p>
								<div class="content">
								

  
										<div class="input-group">
										
										<br><br>
										<input type="password" name="password" class="form-control">
										</div>
										<br>
										<button type="submit" name="submit" value="Login"><i class='material-icons'>lock_outline</i> Log in</button>
										</form>
										<br><br>
										
										
										<div>
		                <center><small>Made with love <i class="fa fa-heart heart"></i> <a href="https://github.com/thatsailorman/ghostbox" target="_blank">Ghostbox</a> & CSS by <a href="http://www.creative-tim.com" target="_blank">Creative Tim</a></small></center>
		            </div>
										</div>
									

									

									
								</div>
								
							
						</div>
					</div>
				</div>
			</div>

			
		       



		</div>

    </div>


</body>
	<!--   Core JS Files   -->
	<script src="../login-assets/js/jquery.min.js" type="text/javascript"></script>
	<script src="../login-assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../login-assets/js/material.min.js"></script>
				<?php
exit();
endif;
?>
</html>

