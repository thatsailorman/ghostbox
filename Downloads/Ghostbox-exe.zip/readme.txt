Install instructions & info: https://github.com/thatsailorman/ghostbox

Contact: erik@zijlstravideo.nl

License: MIT, do whatever the you want it. ;-)
However, [G]hostbox uses third party binaries. Please read their license files as well.