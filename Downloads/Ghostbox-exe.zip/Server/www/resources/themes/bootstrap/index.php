<!DOCTYPE html>
<html>
    <head>

        <title>GhostBox</title>
        <link rel="shortcut icon" href="<?php echo THEMEPATH; ?>/img/folder.png">

    

        <!-- SCRIPTS -->
   
        <script type="text/javascript" src="<?php echo THEMEPATH; ?>/js/directorylister.js"></script>

        <!-- META -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
		
		
  
    </head>

   <body>

        <div id="page-content" class="container">



  
														
	

            <?php if($lister->getSystemMessages()): ?>
                <?php foreach ($lister->getSystemMessages() as $message): ?>
                    <div class="alert alert-<?php echo $message['type']; ?>">
                        <?php echo $message['text']; ?>
                        <a class="close" data-dismiss="alert" href="#">&times;</a>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <div id="directory-list-header">
                <div class="row">
                    <div class="col-md-7 col-sm-6 col-xs-10">File</div>
                  <div class="col-md-2 col-sm-2 col-xs-2 text-right">Size</div>
                </div>
            </div>

            <ul id="directory-listing" class="nav nav-pills nav-stacked">

			
			
                <?php foreach($dirArray as $name => $fileInfo): ?>

                    <li data-name="<?php echo $name; ?>" data-href="<?php echo $fileInfo['url_path']; ?>">
                        <a href="<?php echo $fileInfo['url_path']; ?>" class="clearfix" data-name="<?php echo $name; ?>">


                            <div class="row">
                                <span class="file-name col-md-7 col-sm-6 col-xs-9">
                                    <i class="fa <?php echo $fileInfo['icon_class']; ?> fa-fw"></i>
                                    <?php echo $name; ?>
										
                                   <i>(<?php echo $fileInfo['file_size'];?>)</i>
                                </span>
                               
							

                            </div>

                        </a>



                    </li>
                <?php endforeach; ?>
				
				<br><br>
            </ul>
			
			
        </div>

        
		

		

        

    </body>

</html>
