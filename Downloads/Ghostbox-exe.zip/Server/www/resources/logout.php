<?php 
session_start();
error_reporting(0);
ini_set('display_errors', 0);
$_SESSION['loggedIn'] = false;
session_destroy();
header("Location: ../index.php");
?>

