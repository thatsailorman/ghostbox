<small>No friends online at the moment.</small>
