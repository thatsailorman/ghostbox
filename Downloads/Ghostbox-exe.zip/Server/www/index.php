<?php 
session_start();
error_reporting(0);
ini_set('display_errors', 0); // Don't echo php errors

//put sha1() encrypted password here - example is 'iamghost'
$password = '1ddafad6705d32839babbc9d24eedb4670eb0e29';

// Set date and time
date_default_timezone_set('Africa/Lagos');

// Open or password protected (optional)
if (isset($_SESSION['loggedIn'])) {
if (isset($_SESSION['password'])) {
		$_SESSION['loggedIn'] = true;
} 
}

require('resources/login.php'); //no login screen, set to login.php to force password protection

// Set website (Ghostbox) title
$sitetitle = 'IamGhost';

// Set site or profile description
$sitedescription = 'The first ever Ghostbox on the deep webz... Beyond epic!';

$key = "055shoutingghost550"; // shoutbox encryption key! the key will be truncated if it's too long

?>
<!--- End of settings --->


<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title><?php echo $sitetitle;?> Ghostbox! Self-hosted, Anonymous, Dark Web File Sharing</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="grey" data-image="assets/img/sidebar-2.jpg">

    <!--   you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple" -->


    	<div class="sidebar-wrapper">
		
            <div class="logo">
                <a data-toggle="modal" data-target="#myModal1" href="#pablo" class="simple-text">
                    <b>Ghostbox [Beta]</b>
                </a><b><i>
				<?php
   include('resources/randomquote.php'); // Output random quote list
?>
            </i></div>

            <ul class="nav">
                <li class="active">
                    <a href="/">
                        <i class="pe-7s-share"></i>
                        <p>Shared Files</p>
                    </a>
                </li>
				<br><br>
				 <li>
                    <a data-toggle="modal" data-target="#myModal2" href="#pablo">
                        <i class="pe-7s-network"></i>
                        <p>Browse Ghost Network</p>
                    </a>
                </li>
				 <li>
                    <a href="https://github.com/thatsailorman/ghostbox"target="_blank">
                        <i class="pe-7s-cloud-download"></i>
                        <p>Get Ghostbox</p>
                    </a>
					
                </li>
				<li>
						<a href="https://github.com/thatsailorman/ghostbox"target="_blank">
						<i class="pe-7s-tools"></i>
						<p>Fork me on Github</p>
						</a>
						</li>
				<!--- Check if logged in, if yes echo logout link -->
				 <?php if (isset($_SESSION['loggedIn'])) {?>
				<li>
						<a href="resources/logout.php">
						<i class="pe-7s-close"></i>
						<p>Logout</p>
						</a>
						</li>
						<?php } ?>
				<!--- End of login check / logout link --->		
            </ul>
			
    	</div>
		
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" data-toggle="modal" data-target="#myModal1" href="#pablo">Self-hosted, uncensored, anonymous file sharing alternative on the dark web</a>
                </div>
					
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-sm hidden-xs"></b>
                                    <span class="notification hidden-sm hidden-xs">1</span>
									<p class="hidden-lg hidden-md">
										1 Notification
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="https://github.com/thatsailorman/ghostbox"target="_blank">Download Ghostbox</a></li>
                              </ul>
 
                        </li>
						<!--- Check if logged in, if yes echo logout link -->
						 <li>
							  <?php if (isset($_SESSION['loggedIn'])) { echo "<a href='resources/logout.php'>Log out</a>"; }?>
							  </li>
                    </ul>
				
                   
					<ul class="nav navbar-nav navbar-right">
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
					
				
                
            </div>
        </nav>


		<!--- test --->
						
						<div class="section section-signup" style="background-image: url('assets/img/ghostsbackdrop.jpg'); background-size: cover; background-position: top center; max-height: 100%; max width: 100%;">
						
						
									<div class="OutlineText" align="right"><br><br><?php echo $sitetitle;?> (<?php echo $_SERVER['SERVER_NAME'];?>)<br></div>
                                         
                                      
						</div>
						<!---- end test --->
        <div class="content">
	<div class="row">
            <div class="container-fluid">
                
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><i class="pe-7s-share"></i> Shared Files <small>by <?php echo $sitetitle;?></small></h4>
                            </div>
                            <div class="content">
                                
                                    <div class="row">
                                        <div class="col-md-12">
                                          <?php
	

    // Include the DirectoryLister class
    require_once('resources/DirectoryLister.php');

    // Initialize the DirectoryLister object
    $lister = new DirectoryLister();

    // Restrict access to current directory
    ini_set('open_basedir', getcwd());

    // Return file hash
    if (isset($_GET['hash'])) {

        // Get file hash array and JSON encode it
        $hashes = $lister->getFileHash($_GET['hash']);
        $data   = json_encode($hashes);

        // Return the data
        die($data);

    }

    if (isset($_GET['zip'])) {

        $dirArray = $lister->zipDirectory($_GET['zip']);

    } else {

        // Initialize the directory array
        if (isset($_GET['dir'])) {
            $dirArray = $lister->listDirectory($_GET['dir']);
        } else {
            $dirArray = $lister->listDirectory('.');
        }

        // Define theme path
        if (!defined('THEMEPATH')) {
            define('THEMEPATH', $lister->getThemePath());
        }

        // Set path to theme index
        $themeIndex = $lister->getThemePath(true) . '/index.php';

        // Initialize the theme
        if (file_exists($themeIndex)) {
            include($themeIndex);
        } else {
            die('ERROR: Failed to initialize theme');
        }

    }
?>  
                                        </div>
                                    </div>

                                  
                                    <div class="clearfix"></div>
                                
								
                            </div>
							
							
                            <!--- Ghostbox friends list (include file) -->
							<div class="header">
                                <h4 class="title"><i class="pe-7s-users"></i> Connected [G]hosts</h4>
								<br>
								<?php include('resources/friendslist.php');?>
								<br><br>
                            </div>
							<!---- end of Ghostbox friends list --->
                        </div>	
                    </div>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">
                               
                            </div>
                            <div class="content">
							<!---- About the author (owner) --->
                                <div class="author">
                                    <img class="avatar border-gray" src="assets/img/default-avatar2.png" alt="profile picture"/>

                                      <h4 class="title"><?php echo $sitetitle;?><br />
                                         <small><?php echo $_SERVER['SERVER_NAME'];?></small>
                                      </h4>
                                    
                                </div>
								<br>
                                <p class="description text-center"> "<?php echo $sitedescription;?>"
                                <br>
							<!--- End of profile of author --->	
								<br>
								<?php include('resources/cryptodonation.php');?>
								</p>
                            <!--- End of crypto donation --->
							<br><br>
							<!---- Shoutbox start ---->
							<center><h4 class="title">Leave a message<br /></h4></center>
<br>
							
							<?PHP
						

$bestand = fopen('resources/shoutboxtext.txt','a+'); 
$regels = file('resources/shoutboxtext.txt'); 

include(dirname(__FILE__)."/resources/phpcrypt/phpCrypt.php");
use PHP_Crypt\PHP_Crypt as PHP_Crypt;
use PHP_Crypt\Cipher as Cipher;

$crypt = new PHP_Crypt($key);

if ( isset ( $_POST['submit'] ) ) { 
  if ( !empty( $_POST['name'] ) && !empty( $_POST['msg'] ) ){ 
	  $name = htmlspecialchars($_POST['name']);
	  $msg = htmlspecialchars($_POST['msg']);
      $shout = '<b>' . $name . '</b>: ' . $msg; 
	  // echo $shout; 
	$encrypt = $crypt->encrypt($shout);
	  $text =  base64_encode($encrypt);
	  
      fwrite($bestand,"\n$text"); 
      fclose($bestand); 
      header("Location: index.php"); 
  } 
   
  else { 
        echo '';       
  }  
} 
fclose($bestand); 
if ( isset ( $_GET['show'] ) ) { 
    if ( $_GET['show'] == 'all'){ $hoeveel = count($regels); } 
    else { $hoeveel = $_GET['show']; } 
} 
else { 
 $hoeveel = 5;     
} 

for($i=count($regels);count($regels)-$i<$hoeveel;$i--){
$line = $regels[$i-1];
$linebase = base64_decode($line);
$decrypt = $crypt->decrypt($linebase);
echo $decrypt; echo"<br>";
}
?> 

<form align="right" action="index.php?show=all" method="post"> 
<div class="row">
<div class="col-md-12">
<div class="form-group">
<small><a href='index.php?show=all'>Show all messages</a></small>
<br><br>
<small><label>Name:</label></small>
<input type="text" class="form-control" name="name" /> 
</div>
</div>
</div>

<div class="row">
<div class="form-group">
<div class="col-md-12">
<small><label>Message</label></small>
<input type="text" class="form-control" name="msg" /> <br />
<input type="hidden" value="<?php echo $_POST['content']; ?>" name="content" />
<button type="submit" name="submit" class="btn btn-info btn-fill pull-right" value="Shout!">Shout</button>
</div>
</div>
</div>
</form> 
<!---- Shoutbox end ---->
							</div>
                            <hr>
                        </div>
                    </div>

                </div>
				
						  
				
            </div>
        
		</div>


		
        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
						<li>
						<b><a href="https://www.torproject.org/" target="_blank">Powered by the TOR Network</a></b>
						</li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> Ghostbox, CSS layout design by <b><a href="http://www.creative-tim.com">Creative Tim</a></b>.
                </p>
            </div>
        </footer>

    </div>
</div>

  <!-- Mini about Modal -->
                    <div class="modal fade modal-mini modal-primary" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header justify-content-center">
                                    <div class="modal-profile">
                                        <i class="nc-icon nc-bulb-63"></i>
                                    </div>
                                </div>
                                <div class="modal-body text-center">
                                    <p><b>About Ghostbox</b><br><br>
									<small>This is the first BETA version release of Ghostbox. More information is coming soon. For now, please check the GITHUB page for the latest updates and info.<br></small>
									
									</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-link btn-simple" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--  End about Modal -->
					
					  <!-- Mini ghost network Modal -->
                    <div class="modal fade modal-mini modal-primary" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header justify-content-center">
                                    <div class="modal-profile">
                                        <i class="nc-icon nc-bulb-63"></i>
                                    </div>
                                </div>
                                <div class="modal-body text-center">
                                    <p><b>List of open Ghostbox servers</b><br><br>
									<small><br><br>
									
									<b>IamGhost</b> (First Ghostbox online for Demo purpose) <i>iclzfuu2nkqg4xke.onion</i><br>
									<br><br>
									More coming soon... (Ghostbox is still in Beta)
									</small>
									</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-link btn-simple" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--  End ghost network Modal -->
					

					
</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

</html>


